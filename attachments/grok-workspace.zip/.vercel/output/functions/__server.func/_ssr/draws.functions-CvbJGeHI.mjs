import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/draws.functions-CvbJGeHI.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var loadDraws_createServerFn_handler = createServerRpc({
	id: "7017d9d861d8846e41615c49d682aa4dbeef996d2385b81a293061edb10300fd",
	name: "loadDraws",
	filename: "src/lib/draws.functions.ts"
}, (opts) => loadDraws.__executeServer(opts));
var loadDraws = createServerFn({ method: "GET" }).handler(loadDraws_createServerFn_handler, async () => {
	const { syncDraws } = await import("./vietlott-sync.server-B4aWyxTD.mjs");
	return syncDraws(false);
});
var refreshDraws_createServerFn_handler = createServerRpc({
	id: "7d44cc01eaa4959b19ac3703a53040d680f652bd622d65ce35e40760c1764d06",
	name: "refreshDraws",
	filename: "src/lib/draws.functions.ts"
}, (opts) => refreshDraws.__executeServer(opts));
var refreshDraws = createServerFn({ method: "POST" }).handler(refreshDraws_createServerFn_handler, async () => {
	const { syncDraws } = await import("./vietlott-sync.server-B4aWyxTD.mjs");
	return syncDraws(true);
});
//#endregion
export { loadDraws_createServerFn_handler, refreshDraws_createServerFn_handler };
