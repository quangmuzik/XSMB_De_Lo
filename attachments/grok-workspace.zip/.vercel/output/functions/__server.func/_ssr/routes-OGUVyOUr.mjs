import { i as __toESM } from "../_runtime.mjs";
import { U as isRedirect, b as require_jsx_runtime, q as require_react, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { i as Check, n as Info, r as Copy } from "../_libs/lucide-react.mjs";
import { n as Route, r as refreshDraws } from "./router-C0KV8zMs.mjs";
import { r as formatSyncTime } from "./vietlott-CREueinY.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-OGUVyOUr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function useServerFn(serverFn) {
	const router = useRouter();
	return import_react.useCallback(async (...args) => {
		try {
			const res = await serverFn(...args);
			if (isRedirect(res)) throw res;
			return res;
		} catch (err) {
			if (isRedirect(err)) {
				err.options._fromLocation = router.stores.location.get();
				return router.navigate(router.resolveRedirect(err).options);
			}
			throw err;
		}
	}, [router, serverFn]);
}
var P_NUM = 6 / 55;
var P_PAIR = 30 / 2970;
var WINDOWS = [
	{
		id: 40,
		label: "40 kỳ"
	},
	{
		id: 80,
		label: "80 kỳ"
	},
	{
		id: 160,
		label: "160 kỳ"
	},
	{
		id: 400,
		label: "400 kỳ"
	},
	{
		id: 0,
		label: "Tất cả"
	}
];
var SIZES = [
	2,
	3,
	4,
	5,
	6
];
var POOL = {
	2: 55,
	3: 34,
	4: 26,
	5: 21,
	6: 18
};
function baselineProb(k) {
	let p = 1;
	for (let i = 0; i < k; i++) p *= (6 - i) / (55 - i);
	return p;
}
function formatDate(iso) {
	const [y, m, d] = iso.split("-");
	return `${d}/${m}/${y}`;
}
function weekday(iso) {
	return [
		"Chủ nhật",
		"Thứ hai",
		"Thứ ba",
		"Thứ tư",
		"Thứ năm",
		"Thứ sáu",
		"Thứ bảy"
	][(/* @__PURE__ */ new Date(`${iso}T00:00:00Z`)).getUTCDay()];
}
function nextDrawDate(lastIso) {
	const start = Date.parse(`${lastIso}T00:00:00Z`);
	for (let step = 1; step <= 5; step++) {
		const day = new Date(start + step * 864e5).getUTCDay();
		if (day === 2 || day === 4 || day === 6) return new Date(start + step * 864e5).toISOString().slice(0, 10);
	}
	return lastIso;
}
function nextDrawId(lastId) {
	return String(Number(lastId) + 1).padStart(lastId.length, "0");
}
function ballLabel(n) {
	return String(n).padStart(2, "0");
}
function agoLabel(ago) {
	if (ago === null) return "chưa từng về đủ bộ";
	if (ago === 0) return "vừa về kỳ mới nhất";
	if (ago === 1) return "1 kỳ trước";
	return `${ago} kỳ trước`;
}
function oneInLabel(probability) {
	if (!Number.isFinite(probability) || probability <= 0) return "—";
	const n = 1 / probability;
	const [whole, frac] = (n >= 100 ? Math.round(n) : Math.round(n * 10) / 10).toFixed(n >= 100 ? 0 : 1).split(".");
	const withDots = whole.replace(/\B(?=(\d{3})+(?!\d))/g, ".");
	if (!frac || Number(frac) === 0) return withDots;
	return `${withDots},${frac}`;
}
function factorLabel(factor) {
	return `${factor.toFixed(1).replace(".", ",")}×`;
}
function sliceWindow(draws, windowId) {
	if (windowId <= 0 || windowId >= draws.length) return draws;
	return draws.slice(0, windowId);
}
function containsAll(drawNums, set) {
	let i = 0;
	for (const n of set) {
		while (i < drawNums.length && drawNums[i] < n) i++;
		if (i >= drawNums.length || drawNums[i] !== n) return false;
		i++;
	}
	return true;
}
function enumerateSubsets(nums, k, visit) {
	const chosen = [];
	const walk = (start) => {
		if (chosen.length === k) {
			visit(chosen.join("-"));
			return;
		}
		const need = k - chosen.length;
		for (let i = start; i <= nums.length - need; i++) {
			chosen.push(nums[i]);
			walk(i + 1);
			chosen.pop();
		}
	};
	walk(0);
}
function recentPenalty(draws, set, k) {
	let factor = 1;
	const latest = draws[0];
	const prev = draws[1];
	if (latest && containsAll(latest.nums, set)) {
		if (k >= 6) factor *= .12;
		else if (k >= 5) factor *= .22;
		else if (k >= 4) factor *= .45;
		else if (k >= 3) factor *= .72;
	} else if (prev && k >= 5 && containsAll(prev.nums, set)) factor *= .55;
	return factor;
}
function rankSets(draws, windowId, k, limit = 8) {
	const window = sliceWindow(draws, windowId);
	const n = window.length;
	const uniform = windowId === 0;
	const numW = /* @__PURE__ */ new Float64Array(56);
	const pairW = /* @__PURE__ */ new Float64Array(3136);
	const hits = /* @__PURE__ */ new Int16Array(56);
	const lastAgo = (/* @__PURE__ */ new Int16Array(56)).fill(-1);
	let weightSum = 0;
	for (let t = 0; t < n; t++) {
		const wt = uniform || n === 1 ? 1 : .55 + .45 * (1 - t / (n - 1));
		weightSum += wt;
		const nums = window[t].nums;
		for (let a = 0; a < nums.length; a++) {
			const i = nums[a];
			numW[i] += wt;
			hits[i]++;
			if (lastAgo[i] < 0) lastAgo[i] = t;
			for (let b = a + 1; b < nums.length; b++) pairW[i * 56 + nums[b]] += wt;
		}
	}
	const kappaW = 24 * (weightSum / n);
	const numFactor = (i) => (numW[i] + kappaW * P_NUM) / ((weightSum + kappaW) * P_NUM);
	const pairFactor = (i, j) => {
		const lo = i < j ? i : j;
		const hi = i < j ? j : i;
		return (pairW[lo * 56 + hi] + kappaW * P_PAIR) / ((weightSum + kappaW) * P_PAIR);
	};
	const hotOrder = Array.from({ length: 55 }, (_, i) => i + 1).sort((a, b) => numFactor(b) - numFactor(a) || a - b);
	const poolSet = new Set(hotOrder.slice(0, Math.min(10, POOL[k])));
	if (k > 2) {
		const pairs = [];
		for (let i = 1; i <= 55; i++) for (let j = i + 1; j <= 55; j++) pairs.push({
			i,
			j,
			f: pairFactor(i, j)
		});
		pairs.sort((a, b) => b.f - a.f);
		for (const pair of pairs) {
			if (poolSet.size >= POOL[k]) break;
			poolSet.add(pair.i);
			if (poolSet.size >= POOL[k]) break;
			poolSet.add(pair.j);
		}
	} else for (const value of hotOrder) poolSet.add(value);
	for (const value of hotOrder) {
		if (poolSet.size >= POOL[k]) break;
		poolSet.add(value);
	}
	const pool = [...poolSet].sort((a, b) => a - b);
	const windowHits = /* @__PURE__ */ new Map();
	for (const draw of window) enumerateSubsets(draw.nums, k, (key) => {
		windowHits.set(key, (windowHits.get(key) ?? 0) + 1);
	});
	const drafts = [];
	const chosen = [];
	const scoreChosen = () => {
		let logPair = 0;
		let inv = 0;
		let pairs = 0;
		let weakest = Number.POSITIVE_INFINITY;
		let best = [
			chosen[0],
			chosen[1],
			0
		];
		for (let a = 0; a < chosen.length; a++) for (let b = a + 1; b < chosen.length; b++) {
			const f = pairFactor(chosen[a], chosen[b]);
			if (f < weakest) weakest = f;
			if (f > best[2]) best = [
				chosen[a],
				chosen[b],
				f
			];
			logPair += Math.log(f);
			inv += 1 / f;
			pairs++;
		}
		const geomPair = Math.exp(logPair / pairs);
		const harmPair = pairs / inv;
		let logNum = 0;
		for (const value of chosen) logNum += Math.log(numFactor(value));
		const geomNum = Math.exp(logNum / chosen.length);
		const nums = chosen.slice();
		const weakGate = k >= 4 ? Math.min(1, weakest / .85) : 1;
		const factor = harmPair ** .72 * geomPair ** .28 * geomNum ** .3 * weakGate * recentPenalty(draws, nums, k);
		drafts.push({
			nums,
			factor,
			weakest,
			bestPair: best,
			hitsWindow: windowHits.get(nums.join("-")) ?? 0
		});
	};
	const walk = (start) => {
		if (chosen.length === k) {
			scoreChosen();
			return;
		}
		const need = k - chosen.length;
		for (let i = start; i <= pool.length - need; i++) {
			chosen.push(pool[i]);
			walk(i + 1);
			chosen.pop();
		}
	};
	walk(0);
	drafts.sort((a, b) => b.factor - a.factor || b.hitsWindow - a.hitsWindow || a.nums[0] - b.nums[0]);
	const top = drafts.slice(0, limit);
	const base = baselineProb(k);
	const combos = top.map((draft) => {
		let hitsAll = 0;
		let seen = null;
		for (let t = 0; t < draws.length; t++) {
			if (!containsAll(draws[t].nums, draft.nums)) continue;
			hitsAll++;
			if (seen === null) seen = t;
		}
		return {
			nums: draft.nums,
			factor: draft.factor,
			chance: base * draft.factor,
			baseline: base,
			weakest: draft.weakest,
			hitsWindow: draft.hitsWindow,
			hitsAll,
			lastAgo: seen,
			bestPair: draft.bestPair
		};
	});
	const hot = hotOrder.slice(0, 12).map((value) => ({
		n: value,
		factor: numFactor(value),
		hits: hits[value],
		lastAgo: lastAgo[value]
	}));
	return {
		windowDraws: n,
		totalDraws: draws.length,
		combos,
		hot
	};
}
var SIZE_COPY = {
	2: {
		label: "Cặp 2",
		note: "Hai số cùng nằm trong 6 số chính. Mức ngẫu nhiên mỗi kỳ là 1 trên 99."
	},
	3: {
		label: "Cặp 3",
		note: "Ba số cùng về. Mức ngẫu nhiên là 1 trên 1.312."
	},
	4: {
		label: "Cặp 4",
		note: "Bốn số cùng về. Mức ngẫu nhiên là 1 trên 22.737."
	},
	5: {
		label: "Cặp 5",
		note: "Năm số cùng về. Mức ngẫu nhiên là 1 trên 579.794."
	},
	6: {
		label: "Cặp 6",
		note: "Đủ một vé 6 số. Mức ngẫu nhiên là 1 trên 28.989.675 — hệ số chỉ nói vé này nóng hơn vé bất kỳ."
	}
};
function Ball({ n, ghost = false, swap = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `inline-flex size-11 shrink-0 items-center justify-center rounded-full text-sm font-semibold tabular-nums ${ghost ? "border-2 border-gold bg-transparent text-gold" : swap ? "border-2 border-gold bg-surface-2 text-fg" : "bg-gold text-ink"}`,
		children: ballLabel(n)
	});
}
function copyText(combo) {
	return combo.nums.map(ballLabel).join(" ");
}
function Board({ snapshot, refreshing, refreshError, onRefresh }) {
	const [windowId, setWindowId] = (0, import_react.useState)(80);
	const [size, setSize] = (0, import_react.useState)(2);
	const [copied, setCopied] = (0, import_react.useState)(null);
	const draws = snapshot.draws;
	const latest = draws[0];
	const status = snapshot.status;
	const upcoming = latest ? nextDrawDate(latest.date) : "";
	const upcomingId = latest ? nextDrawId(latest.id) : "";
	const ranked = (0, import_react.useMemo)(() => rankSets(draws, windowId, size, 8), [
		draws,
		windowId,
		size
	]);
	const lead = ranked.combos[0];
	const leadSet = (0, import_react.useMemo)(() => new Set(lead?.nums ?? []), [lead]);
	const windowLabel = WINDOWS.find((item) => item.id === windowId)?.label ?? "";
	const core = (0, import_react.useMemo)(() => {
		const counts = /* @__PURE__ */ new Map();
		for (const combo of ranked.combos) for (const n of combo.nums) counts.set(n, (counts.get(n) ?? 0) + 1);
		const need = Math.max(3, Math.ceil(ranked.combos.length * .6));
		return [...counts.entries()].filter(([, count]) => count >= need).sort((a, b) => b[1] - a[1] || a[0] - b[0]).map(([n]) => n);
	}, [ranked]);
	async function copyValue(key, value) {
		try {
			await navigator.clipboard.writeText(value);
			setCopied(key);
		} catch {
			setCopied(null);
		}
	}
	async function copyBoard() {
		await copyValue("board", [
			`Power 6/55 · ${SIZE_COPY[size].label} · cửa sổ ${windowLabel}`,
			`Kỳ tới #${upcomingId} · ${weekday(upcoming)} ${formatDate(upcoming)}`,
			...ranked.combos.map((combo, index) => `${index + 1}. ${copyText(combo)} · ${factorLabel(combo.factor)}`)
		].join("\n"));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "desk min-h-screen",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex w-full max-w-5xl flex-col gap-6 px-4 py-6 sm:px-6 sm:py-10",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold tracking-widest text-gold uppercase",
							children: "Power 6/55"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-4xl leading-tight text-fg sm:text-5xl",
							children: "Cặp số dễ về kỳ tới"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "max-w-2xl text-base leading-relaxed text-muted",
							children: "Xếp hạng cặp 2, 3, 4, 5 và 6 số theo xác suất tương đối. Bộ nào các số hay đi cùng nhau trong các kỳ gần sẽ đứng trên — không phải bộ chỉ xuất hiện nhiều từ năm 2017."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					role: "status",
					"aria-live": "polite",
					className: `rounded-2xl border p-4 ${!latest || !status.ok ? "border-hot bg-surface" : status.warning ? "border-gold bg-surface" : "border-line bg-surface"}`,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0",
							children: [
								!latest || !status.ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-hot",
									children: "Chưa cập nhật được kết quả mới"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm leading-relaxed text-fg",
									children: [
										refreshError || status.error || "Không lấy được dữ liệu mới.",
										" Đang hiển thị bản gần nhất",
										latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
											": kỳ #",
											latest.id,
											" ngày ",
											formatDate(latest.date)
										] }) : null,
										status.fetchedAt ? ` — lần đồng bộ thành công gần nhất ${formatSyncTime(status.fetchedAt)}.` : " — đây là bản lưu đi kèm ứng dụng, không phải lần kiểm tra vừa rồi."
									]
								})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-semibold text-fg",
									children: status.added > 0 ? `Đã thêm ${status.added} kỳ mới và tính lại thống kê` : "Đã kiểm tra nguồn — không có kỳ mới hơn"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: [
										"Lần kiểm tra ",
										formatSyncTime(status.checkedAt),
										". Nguồn: ",
										status.sourceLabel,
										". Lịch sử",
										" ",
										status.drawCount,
										" kỳ, mới nhất #",
										status.latestId,
										" ngày ",
										formatDate(status.latestDate),
										"."
									]
								})] }),
								refreshError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-hot",
									children: refreshError
								}) : null,
								status.ok && status.warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-gold",
									children: status.warning
								}) : null,
								!status.ok && status.warning ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-muted",
									children: status.warning
								}) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: onRefresh,
							disabled: refreshing,
							className: "inline-flex min-h-11 shrink-0 items-center justify-center rounded-full border border-line bg-surface-2 px-4 text-sm font-semibold text-fg disabled:opacity-60",
							children: refreshing ? "Đang lấy số mới…" : "Cập nhật kết quả"
						})]
					})
				}),
				latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid gap-4 lg:grid-cols-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-line bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Kỳ vừa quay"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-1 text-xl font-semibold text-fg",
								children: [
									"#",
									latest.id,
									" · ",
									weekday(latest.date),
									" ",
									formatDate(latest.date)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex flex-wrap items-center gap-2",
								children: [latest.nums.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n }, n)), latest.bonus != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "mx-1 hidden h-8 w-px bg-line sm:block",
									"aria-hidden": "true"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "flex items-center gap-2",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
										n: latest.bonus,
										ghost: true
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted",
										children: "Đặc biệt"
									})]
								})] }) : null]
							})
						]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "rounded-2xl border border-gold bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-gold",
								children: "Kỳ tới · bộ mạnh nhất"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "mt-1 text-xl font-semibold text-fg",
								children: [
									"#",
									upcomingId,
									" · ",
									weekday(upcoming),
									" ",
									formatDate(upcoming)
								]
							}),
							lead ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 flex flex-wrap gap-2",
									children: lead.nums.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n }, n))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-display text-4xl text-gold",
									children: factorLabel(lead.factor)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-1 text-sm leading-relaxed text-muted",
									children: [
										"Nếu mẫu ",
										windowLabel.toLowerCase(),
										" tiếp tục, bộ này khoảng 1 trên ",
										oneInLabel(lead.chance),
										". Bộ ngẫu nhiên cùng cỡ là 1 trên ",
										oneInLabel(lead.baseline),
										"."
									]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-sm leading-relaxed text-fg",
									children: "Thống kê lịch sử không bảo đảm dự đoán chính xác kỳ tiếp theo."
								})
							] }) : null
						]
					})]
				}) : null,
				draws.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold text-fg",
							children: "Lịch sử kỳ gần"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [draws.length, " kỳ"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 divide-y divide-line",
						children: draws.slice(0, 8).map((draw) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex flex-wrap items-baseline justify-between gap-x-4 gap-y-1 py-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm text-muted",
								children: [
									"#",
									draw.id,
									" · ",
									weekday(draw.date),
									" ",
									formatDate(draw.date)
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-semibold tabular-nums text-fg",
								children: [draw.nums.map(ballLabel).join(" "), draw.bonus != null ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-gold",
									children: [" · ", ballLabel(draw.bonus)]
								}) : null]
							})]
						}, draw.id))
					})]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							role: "group",
							"aria-label": "Cỡ bộ số",
							children: SIZES.map((value) => {
								const active = value === size;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": active,
									onClick: () => setSize(value),
									className: `min-h-11 rounded-full border px-4 text-sm font-semibold ${active ? "border-gold bg-gold text-ink" : "border-line bg-surface text-fg"}`,
									children: SIZE_COPY[value].label
								}, value);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							role: "group",
							"aria-label": "Cửa sổ thống kê",
							children: WINDOWS.map((item) => {
								const active = item.id === windowId;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									"aria-pressed": active,
									onClick: () => setWindowId(item.id),
									className: `min-h-11 rounded-full border px-4 text-sm font-medium ${active ? "border-gold bg-surface-2 text-gold" : "border-line bg-surface text-muted"}`,
									children: item.label
								}, item.id);
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm leading-relaxed text-muted",
							children: SIZE_COPY[size].note
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-surface p-5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-lg font-semibold text-fg",
							children: "Số đang nóng"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-muted",
							children: [ranked.windowDraws, " kỳ"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 flex max-w-full gap-3 overflow-x-auto pb-1",
						children: ranked.hot.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex w-14 shrink-0 flex-col items-center gap-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, { n: item.n }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-semibold text-gold",
									children: factorLabel(item.factor)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-xs text-muted",
									children: [item.hits, " lần"]
								})
							]
						}, item.n))
					})]
				}),
				core.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm leading-relaxed text-muted",
					children: [
						"Các bộ hạng cao đang xoay quanh cụm",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold text-fg",
							children: core.map(ballLabel).join(" · ")
						}),
						size >= 4 ? ". Số có viền ở danh sách là số khác so với bộ hạng 1." : "."
					]
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
								className: "text-lg font-semibold text-fg",
								children: ["Hạng ", SIZE_COPY[size].label.toLowerCase()]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void copyBoard(),
								className: "inline-flex min-h-11 items-center gap-2 rounded-full border border-line bg-surface px-4 text-sm font-medium text-fg",
								children: [copied === "board" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-gold" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied === "board" ? "Đã chép" : "Chép top"]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "sr-only",
							"aria-live": "polite",
							children: copied ? "Đã chép bộ số" : ""
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "flex flex-col gap-3",
							children: ranked.combos.map((combo, index) => {
								const key = combo.nums.join("-");
								const width = lead ? Math.max(8, Math.round(combo.factor / lead.factor * 100)) : 0;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-2xl border border-line bg-surface p-4 sm:p-5",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "font-display text-2xl text-gold",
												children: String(index + 1).padStart(2, "0")
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
												className: "text-right",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "block font-display text-3xl text-fg",
													children: factorLabel(combo.factor)
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
													className: "text-xs text-muted",
													children: "so với ngẫu nhiên"
												})]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-3 flex flex-wrap gap-2",
											children: combo.nums.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ball, {
												n,
												swap: index > 0 && size >= 4 && !leadSet.has(n)
											}, n))
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-4 h-1.5 overflow-hidden rounded-full bg-surface-2",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full bg-gold",
												style: { width: `${width}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-3 text-sm leading-relaxed text-muted",
											children: [
												combo.hitsWindow,
												" lần trong ",
												ranked.windowDraws,
												" kỳ này · ",
												combo.hitsAll,
												" lần từ 2017 ·",
												" ",
												agoLabel(combo.lastAgo),
												size > 2 ? ` · cặp yếu nhất ${factorLabel(combo.weakest)}` : ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-sm leading-relaxed text-fg",
											children: ["Ước lượng 1 trên ", oneInLabel(combo.chance)]
										}),
										size > 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-sm leading-relaxed text-muted",
											children: [
												"Cặp ăn ý nhất: ",
												ballLabel(combo.bestPair[0]),
												"–",
												ballLabel(combo.bestPair[1]),
												" (",
												factorLabel(combo.bestPair[2]),
												")"
											]
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
											type: "button",
											onClick: () => void copyValue(key, copyText(combo)),
											className: "mt-3 inline-flex min-h-11 items-center gap-2 rounded-full border border-line px-4 text-sm font-medium text-fg",
											children: [copied === key ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4 text-gold" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-4" }), copied === key ? "Đã chép" : "Chép bộ số"]
										})
									]
								}, key);
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-2xl border border-line bg-surface-2 p-5 text-sm leading-relaxed text-muted",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "flex items-start gap-2 text-fg",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Info, {
								className: "mt-0.5 size-4 shrink-0 text-gold",
								"aria-hidden": "true"
							}), "Thống kê lịch sử không bảo đảm dự đoán chính xác kỳ tiếp theo. Máy quay không có trí nhớ — đây là xếp hạng mẫu đã xảy ra, không phải cam kết trúng."]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
							className: "mt-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
								className: "cursor-pointer font-medium text-fg",
								children: "Cách chấm điểm"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
								className: "mt-2 list-disc space-y-1 pl-5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Chỉ tính 6 số chính. Số đặc biệt không đưa vào cặp." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Kỳ gần trong cửa sổ được tính nặng hơn kỳ cũ. Chọn Tất cả thì mọi kỳ ngang nhau." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Mỗi cặp được so với mức 1/99. Bộ lớn lấy trung bình các cặp bên trong và bị kéo xuống nếu có một cặp yếu." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Bộ 4 số trở lên vừa nổ ở kỳ mới nhất bị giảm điểm, vì rất hiếm lặp lại ngay." }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Hệ số 3× nghĩa là bộ đó đang nóng gấp khoảng 3 lần một bộ cùng cỡ chọn hú họa — nếu mẫu gần đây còn đúng." })
								]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3",
							children: [
								draws.length > 0 && latest ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									draws.length,
									" kỳ, từ ",
									formatDate(draws[draws.length - 1].date),
									" đến ",
									formatDate(latest.date),
									".",
									" "
								] }) : null,
								"Kết quả được kéo lại mỗi lần mở trang từ kho",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-gold underline underline-offset-4",
									href: "https://github.com/vietvudanh/vietlott-data",
									target: "_blank",
									rel: "noreferrer",
									children: "vietlott-data"
								}),
								" ",
								"(cào hàng ngày từ vietlott.vn), kỳ mới nhất đối chiếu thêm",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-gold underline underline-offset-4",
									href: "https://www.minhngoc.net.vn/ket-qua-xo-so/dien-toan-vietlott/power-6x55.html",
									target: "_blank",
									rel: "noreferrer",
									children: "Minh Ngọc"
								}),
								", và trang",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-gold underline underline-offset-4",
									href: "https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/655",
									target: "_blank",
									rel: "noreferrer",
									children: "vietlott.vn"
								}),
								" ",
								"khi trang này cho phép máy chủ đọc. Không có số nào được tự tạo."
							]
						})
					]
				})
			]
		})
	});
}
function Home() {
	const initial = Route.useLoaderData();
	const refresh = useServerFn(refreshDraws);
	const [snapshot, setSnapshot] = (0, import_react.useState)(initial);
	const [seen, setSeen] = (0, import_react.useState)(initial.status.checkedAt);
	const [refreshing, setRefreshing] = (0, import_react.useState)(false);
	const [refreshError, setRefreshError] = (0, import_react.useState)(null);
	if (seen !== initial.status.checkedAt) {
		setSeen(initial.status.checkedAt);
		setSnapshot(initial);
	}
	async function onRefresh() {
		setRefreshing(true);
		setRefreshError(null);
		try {
			setSnapshot(await refresh());
		} catch (error) {
			setRefreshError(error instanceof Error ? error.message : "Không cập nhật được.");
		} finally {
			setRefreshing(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {
		snapshot,
		refreshing,
		refreshError,
		onRefresh: () => void onRefresh()
	});
}
//#endregion
export { Home as component };
